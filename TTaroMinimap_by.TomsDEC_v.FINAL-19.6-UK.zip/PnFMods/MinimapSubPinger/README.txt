MinimapSubPinger (API_v2) — companion to TTaro Minimap
Creates minimapAttentionPoint entities for enemy submarine pings & oil leaks.
TTaro Minimap unbound already renders them (red circle / sub icon / direction).
Do not install a second copy via Aslain at the same time (duplicate markers).
