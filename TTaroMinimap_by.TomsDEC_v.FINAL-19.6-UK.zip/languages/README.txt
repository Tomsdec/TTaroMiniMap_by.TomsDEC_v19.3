# Languages / Langues

## How TTaro labels work

TTaro Mod Config shows:
- **IDS_*** keys → translated by TTaro Mod Config language packs (follow game language when available)
- **Plain text** → always shown as written in the schema (same for every player)

This pack uses:
1. **Original TTaro IDS_** keys restored where possible (player name, ship name, distance, etc.) so they follow the game/TTaro language.
2. **English plain text** for features added in this custom pack (group colors, sub pings, camera opacity, etc.).

## Files

- `en.json` — English reference (matches schema)
- `fr.json` — French reference (for translators / future tools)

These JSON files are **documentation only**: the game does not load them automatically.
To ship a full French UI again, replace the English strings in
`ModSchemas/ttaro-minimap.schema.json` with the values from `fr.json`.

## Pourquoi pas un switch auto FR/EN ?

Sans fichier de langue officiel dans **TTaro Mod Config**, les libellés en texte libre
ne changent pas avec la langue du client. Utiliser des IDS inconnus afficherait des clés
illisibles. L’anglais en schéma + IDS d’origine = solution stable qui ne casse rien.
