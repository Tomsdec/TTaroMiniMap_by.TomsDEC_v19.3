API_VERSION = 'API_v1.0'
MOD_NAME = 'TTaroMinimap'

try:
    import events, ui, utils, dataHub, constants, battle
except:
    pass

from math import radians, degrees
from EntityController import EntityController


CC = constants.UiComponents
ShipTypes = constants.ShipTypes
KM_TO_BW = 1000.0 / 30.0


def logInfo(*args):
    data = [str(i) for i in args]
    utils.logInfo( '[{}] {}'.format(MOD_NAME, ', '.join(data)) )


class ShipConsumableChecker(object):
    """
    Checks the ship consumables in a match
    """

    COMPONENT_KEY = 'modTTaroMinimapConsumableRanges'

    TITLE_TO_INFO = {
        'RLSSearch'         : {'type': 'radar',             'attr': 'distShip'},
        'SonarSearch'       : {'type': 'hydro',             'attr': 'distShip'},
        'SubmarineLocator'  : {'type': 'subRadar',          'attr': 'acousticWaveMaxDist_submarine_detection'},
        #'Hydrophone'        : {'type': 'hydrophone',        'attr': 'hydrophoneWaveRadius'},
    }

    def __init__(self):
        self.entityController = EntityController(ShipConsumableChecker.COMPONENT_KEY)
        events.onBattleShown(self.__onBattleStart)
        events.onBattleQuit(self.__onBattleEnd)

    def __onBattleStart(self, *args):
        self.entityController.createEntity()
        data = self._getAllConsumablesData()
        self.entityController.updateEntity(data)

        logInfo('Ship consumables have been updated.')

    def __onBattleEnd(self, *args):
        self.entityController.removeEntity()

    def _getAllConsumablesData(self):
        consumablesData = {}
        for entity in dataHub.getEntityCollections('shipBattleInfo'):
            ship = entity[CC.shipBattleInfo]
            data = self._getConsumablesDataByShip(ship)
            if data is not None:
                consumablesData[ship.playerId] = data

        return consumablesData
    
    def _getConsumablesDataByShip(self, ship):
        data = {}
        allConsumables = ship.mainConsumables + [cons for consList in ship.altConsumables for cons in consList]
        for cons in allConsumables:
            consInfo = self.__getConsumableInfo(cons)
            if consInfo is None:
                continue
            consType = consInfo['type']
            data[consType] = self.__getConsumableRanges(cons, consInfo)

        if len(data) > 0:
            return data
        return None

    def __getConsumableInfo(self, consumable):
        consName = consumable.title
        for ident, consInfo in ShipConsumableChecker.TITLE_TO_INFO.iteritems():
            if ident.upper() in consName:
                return consInfo
        return None

    def __getConsumableRanges(self, consumable, consInfo):
        paramName = consInfo['attr']
        for attr in consumable.activeAttributes.neutral:
            if attr.paramName == paramName:
                bw = attr.numericValue * KM_TO_BW
                data = {'world': attr.numericValue, 'map': ui.getLengthOnMiniMap(bw)}
                return  data
            
consChecker = ShipConsumableChecker()



RPF_SECTOR_WIDTH_DEG = 360.0 / 16.0
RPF_SECTOR_WIDTH_RAD = radians(RPF_SECTOR_WIDTH_DEG)

RPF_SECTOR_HALF_WIDTH_DEG = RPF_SECTOR_WIDTH_DEG / 2.0
RPF_SECTOR_HALF_WIDTH_RAD = radians(RPF_SECTOR_HALF_WIDTH_DEG)

INVALID_DIRECTION = -1
RPF_MESSAGE_TO_DIRECTION = {
	'RPF: N~NNE':  1,
	'RPF: NNE~NE': 2,
	'RPF: NE~ENE': 3,
	'RPF: ENE~E':  4,
	'RPF: E~ESE':  5,
	'RPF: ESE~SE': 6,
	'RPF: SE~SSE': 7,
	'RPF: SSE~S':  8,
	'RPF: S~SSW':  9,
	'RPF: SSW~SW': 10,
	'RPF: SW~WSW': 11,
	'RPF: WSW~W':  12,
	'RPF: W~WNW':  13,
	'RPF: WNW~NW': 14,
	'RPF: NW~NNW': 15,
	'RPF: NNW~N':  16,
    'RPF: None':   INVALID_DIRECTION,
}


class RadioLocation(object):
    COMPONENT_KEY = 'modTTaroMinimapRadioLocation'

    def __init__(self):
        events.onBattleShown(self.__onBattleStart)
        events.onBattleQuit(self.__onBattleEnd)
        self.entityController = EntityController(RadioLocation.COMPONENT_KEY)
        self._selfPlayerId = 0
        self._rpfDirections = {}
        self._chatComponent = None
        self._rpfComponent = None

    def __onBattleStart(self, *args):
        self._rpfDirections.clear()
        self._selfPlayerId = battle.getSelfPlayerInfo().id
        chatEntity = dataHub.getSingleEntity('battleChatAndLog')
        if chatEntity:
            self.entityController.createEntity()

            chat = chatEntity[CC.battleChatAndLog]
            chat.evMessageReceived.add(self.__onChatReceived)
            self._chatComponent = chat

        rpfEntity = dataHub.getSingleEntity('nearestEnemyIndication')
        if rpfEntity:
            rpf = rpfEntity[CC.nearestEnemyIndication]
            rpf.evYawToNearestEnemyChanged.add(self.__onYawToNearestEnemyChanged)
            rpf.evShowNearestEnemyChanged.add(self.__onShowNearestEnemyChanged)
            self._rpfComponent = rpf
        
        logInfo('Initialized RPF controller')

    def __onBattleEnd(self, *args):
        if self._chatComponent:
            try:
                self._chatComponent.evMessageReceived.remove(self.__onChatReceived)
            except:
                logInfo('Error while trying to remove the event from chat')
            self._chatComponent = None

        if self._rpfComponent:
            rpf = self._rpfComponent
            try:
                rpf.evYawToNearestEnemyChanged.remove(self.__onYawToNearestEnemyChanged)
                rpf.evShowNearestEnemyChanged.remove(self.__onShowNearestEnemyChanged)
            except:
                logInfo('Error while trying to remove the event from RPF')

        self._rpfDirections.clear()
        self.entityController.removeEntity()
        self._selfPlayerId = 0

        logInfo('Cleared RPF controller')

    def __onYawToNearestEnemyChanged(self, component):
        rpfDirRad = component.yawToNearestEnemy - RPF_SECTOR_HALF_WIDTH_RAD

        self._rpfDirections[self._selfPlayerId] = degrees(rpfDirRad)
        self.entityController.updateEntity(self._rpfDirections)

    def __onShowNearestEnemyChanged(self, component):
        if component.showNearestEnemy:
            self.__onYawToNearestEnemyChanged(component)
        else:
            self.__updateDataByDirIndex(self._selfPlayerId, INVALID_DIRECTION)

    def __updateDataByDirIndex(self, playerId, rpfDirIndex):
        if rpfDirIndex != INVALID_DIRECTION:
            rpfDirRad = RPF_SECTOR_WIDTH_RAD * (rpfDirIndex - 1)
            self._rpfDirections[playerId] = degrees(rpfDirRad)
        else:
            self._rpfDirections[playerId] = INVALID_DIRECTION
        self.entityController.updateEntity(self._rpfDirections)

    def __onChatReceived(self, component):
        entity = dataHub.getEntityCollections('battleChatAndLogMessage')[-1]
        comp = entity[CC.battleChatAndLogMessage]
        senderId = comp.playerId
        if senderId == self._selfPlayerId:
            return
        # enemies may type chat directly
        # but the sector element isn't initialized for enemies in Unbound anyway
        rpfDirIndex = self._getDirectionIndex(comp.message)
        if rpfDirIndex is not None:
            self.__updateDataByDirIndex(senderId, rpfDirIndex)

    def _getDirectionIndex(self, message):
        # None if no signature is contained
        return RPF_MESSAGE_TO_DIRECTION.get(message, None)


gRadioLocation = RadioLocation()

class DivisionMarks(object):
    """
    Battle-local ship colour groups (Groupe 1 / Groupe 2).

    Alt + click on minimap cycles each ship: none -> 1 -> 2 -> none.
    Unbound reads modTTaroMinimapDivisionMarks: { avatarId: groupNumber }.
    Feature can be disabled via ttaro.minimap.shipMarker.groups.enabled (Unbound side).
    """

    COMPONENT_KEY = 'modTTaroMinimapDivisionMarks'
    PREF_SUB_X = 'ttDiv1X'
    PREF_SUB_Y = 'ttDiv1Y'
    # Distance filter kept loose on purpose (coords unreliable at range); user accepted this.
    MAX_DIST_SQ = 900.0 * 900.0
    GROUP_MAX = 2  # cycle 0 -> 1 -> 2 -> 0

    def __init__(self):
        self.entityController = EntityController(DivisionMarks.COMPONENT_KEY)
        self._marks = {}  # str(avatarId) -> group int (1 or 2)
        self._pendingX = None
        self._selfId = 0
        events.onBattleShown(self.__onBattleStart)
        events.onBattleQuit(self.__onBattleEnd)
        try:
            events.onSFMEvent(self.__onSFM)
        except Exception as e:
            logInfo('DivisionMarks: could not register onSFMEvent: %r' % (e,))

    def __onBattleStart(self, *args):
        self._marks = {}
        self._pendingX = None
        self._selfId = 0
        try:
            self._selfId = int(battle.getSelfPlayerInfo().id)
        except Exception:
            try:
                for ent in dataHub.getEntityCollections('playerAvatar'):
                    av = ent[CC.playerAvatar]
                    self._selfId = int(getattr(av, 'id', 0) or 0)
                    break
            except Exception:
                self._selfId = 0
        self.entityController.createEntity({})
        logInfo('DivisionMarks ready (self=%s)' % self._selfId)

    def __onBattleEnd(self, *args):
        self._marks = {}
        self._pendingX = None
        self.entityController.removeEntity()
        logInfo('DivisionMarks cleared')

    def __publish(self):
        """Replace the data component entirely so removed marks disappear in Unbound."""
        try:
            self.entityController.removeEntity()
            self.entityController.createEntity(dict(self._marks))
        except Exception as e:
            logInfo('DivisionMarks publish failed: %r' % (e,))
            try:
                self.entityController.createEntity(dict(self._marks))
            except Exception as e2:
                logInfo('DivisionMarks publish retry failed: %r' % (e2,))

    def __cycle(self, avatar_id):
        key = str(avatar_id)
        cur = int(self._marks.get(key, 0) or 0)
        nxt = cur + 1
        if nxt > DivisionMarks.GROUP_MAX:
            if key in self._marks:
                del self._marks[key]
            logInfo('DivisionMarks: avatar %s -> clear' % key)
        else:
            self._marks[key] = nxt
            logInfo('DivisionMarks: avatar %s -> group %d' % (key, nxt))
        self.__publish()

    def __find_nearest(self, x, y):
        best_id = None
        best_d = DivisionMarks.MAX_DIST_SQ
        tried = 0
        try:
            collection = dataHub.getEntityCollections('avatar')
        except Exception:
            collection = []
        for ent in collection or []:
            tried += 1
            try:
                av = ent[CC.avatar]
                avatar_id = int(av.id)
                if avatar_id <= 0:
                    continue
                if self._selfId and avatar_id == self._selfId:
                    continue
                pos_comp = ent[CC.mapPosition]
                pos = pos_comp.position
                dx = float(pos.x) - x
                dy = float(pos.y) - y
                d = dx * dx + dy * dy
                if d <= best_d:
                    best_d = d
                    best_id = avatar_id
            except Exception:
                continue
        logInfo('DivisionMarks: click (%.2f, %.2f) nearest=%s distSq=%.1f tried=%d' % (
            x, y, best_id, best_d if best_id is not None else -1, tried))
        return best_id

    def __onSFM(self, *args):
        try:
            name = str(args[0]) if args else ''
            if name.lower() != 'action.setuserpref':
                return
            payload = args[1] if len(args) > 1 and isinstance(args[1], dict) else {}
            sub = payload.get('subName')
            if sub not in (DivisionMarks.PREF_SUB_X, DivisionMarks.PREF_SUB_Y):
                return
            try:
                value = float(payload.get('value', 0))
            except Exception:
                return
            SENTINEL = -1000000000.0
            if sub == DivisionMarks.PREF_SUB_X:
                if value <= SENTINEL + 1:
                    self._pendingX = None
                    return
                self._pendingX = value
                return
            x = self._pendingX
            self._pendingX = None
            if x is None:
                return
            if value <= SENTINEL + 1:
                return
            y = value
            avatar_id = self.__find_nearest(x, y)
            if avatar_id:
                self.__cycle(avatar_id)
            else:
                logInfo('DivisionMarks: no ship within range at (%.1f, %.1f)' % (x, y))
        except Exception as e:
            logInfo('DivisionMarks SFM error: %r' % (e,))


gDivisionMarks = DivisionMarks()

